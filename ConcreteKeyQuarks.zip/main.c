#include <stdio.h>

int main(void) {
  int i;
  //iniciação; condição; iteração
  for (i=0 ;i<=100 ; i+=5 ) printf("%d ", i);
  return 0;
}